# Exercise 4.1 - SVG House

COS30045 Data Visualisation

A house scene drawn with SVG shapes using D3.js.

## Files

- `index.html` - page and drawing code
- `css/site.css` - styles
- `images/` - annotated drawing and DevTools screenshot

GenAI was used in this exercise. See the GenAI declaration on Canvas.
