# Exercises 4.3 to 4.6 - Bar Chart

COS30045 Data Visualisation

A horizontal bar chart of TV models by brand, built with D3.js.

## Files

- `index.html` - page
- `main.js` - bar chart code
- `css/` - styles
- `data/ex.csv` - number of TV models per brand

GenAI was used in this exercise. See the GenAI declaration on Canvas.
