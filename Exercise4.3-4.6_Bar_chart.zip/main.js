const width = 500;
const height = 600;

const svg = d3.select(".responsive-svg-container")
  .append("svg")
    .attr("viewBox", `0 0 ${width} ${height}`);

// load data
d3.csv("data/ex.csv", d => {
  return {
    brand: d.brand,
    count: +d.count
  };
}).then(data => {
  console.log(data);
  data.sort((a, b) => b.count - a.count);
  drawBarChart(data);
});

const drawBarChart = data => {
  const labelSpace = 100;

  // scales
  const xScale = d3.scaleLinear()
    .domain([0, d3.max(data, d => d.count)])
    .range([0, 350]);

  const yScale = d3.scaleBand()
    .domain(data.map(d => d.brand))
    .range([0, height])
    .padding(0.2);

  // one group per brand
  const barAndLabel = svg
    .selectAll("g")
    .data(data)
    .join("g")
      .attr("transform", d => `translate(0, ${yScale(d.brand)})`);

  // bars
  barAndLabel
    .append("rect")
      .attr("class", d => `bar bar-${d.count}`)
      .attr("x", labelSpace)
      .attr("y", 0)
      .attr("width", d => xScale(d.count))
      .attr("height", yScale.bandwidth())
      .attr("fill", "steelblue");

  // brand names
  barAndLabel
    .append("text")
      .text(d => d.brand)
      .attr("x", labelSpace - 10)
      .attr("y", yScale.bandwidth() / 2)
      .attr("text-anchor", "end")
      .attr("dominant-baseline", "middle")
      .style("font-size", "13px");

  // values
  barAndLabel
    .append("text")
      .text(d => d.count)
      .attr("x", d => labelSpace + xScale(d.count) + 5)
      .attr("y", yScale.bandwidth() / 2)
      .attr("dominant-baseline", "middle")
      .style("font-size", "13px");
};