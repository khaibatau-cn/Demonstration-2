# Exercise 5 - Multi-chart Page

COS30045 Data Visualisation

Three D3.js charts about TV energy use on one page.

## Files

- `index.html` - page
- `js/barChart.js` - Ex 5.1 vertical bar chart
- `js/line-chart.js` - Ex 5.2 scatter plot and line chart
- `js/donut-chart.js` - Ex 5.3 donut chart
- `css/` - styles
- `data/` - CSV files

GenAI was used in this exercise. See the GenAI declaration on Canvas.
