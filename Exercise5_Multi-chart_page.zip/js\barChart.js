d3.csv("data/tv55ScreenTech.csv", d => {
  return {
    screenTech: d.screenTech,
    energy: +d.energy
  };
}).then(data => {
  console.log(data);
  data.sort((a, b) => b.energy - a.energy);
  drawBarChart(data);
});

const drawBarChart = data => {
  const width = 800;
  const height = 500;
  const margin = { top: 50, right: 30, bottom: 50, left: 70 };
  const innerWidth = width - margin.left - margin.right;
  const innerHeight = height - margin.top - margin.bottom;

  const svg = d3.select("#bar-chart")
    .append("svg")
      .attr("viewBox", `0 0 ${width} ${height}`);

  const innerChart = svg
    .append("g")
      .attr("transform", `translate(${margin.left}, ${margin.top})`);

  // scales
  const xScale = d3.scaleBand()
    .domain(data.map(d => d.screenTech))
    .range([0, innerWidth])
    .padding(0.3);

  const yScale = d3.scaleLinear()
    .domain([0, d3.max(data, d => d.energy) * 1.1])
    .range([innerHeight, 0])
    .nice();

  // axes
  const bottomAxis = d3.axisBottom(xScale).tickSize(0);
  const leftAxis = d3.axisLeft(yScale);

  innerChart
    .append("g")
      .attr("class", "x-axis")
      .attr("transform", `translate(0, ${innerHeight})`)
      .call(bottomAxis)
    .selectAll("text")
      .attr("dy", "1.5em")
      .style("font-size", "14px");

  innerChart
    .append("g")
      .attr("class", "y-axis")
      .call(leftAxis)
    .selectAll("text")
      .style("font-size", "12px");

  svg
    .append("text")
      .text("Average energy consumption (kWh/year)")
      .attr("x", 10)
      .attr("y", 25)
      .attr("text-anchor", "start")
      .style("font-size", "14px");

  // bars
  innerChart
    .selectAll("rect")
    .data(data)
    .join("rect")
      .attr("class", "bar")
      .attr("x", d => xScale(d.screenTech))
      .attr("y", d => yScale(d.energy))
      .attr("width", xScale.bandwidth())
      .attr("height", d => innerHeight - yScale(d.energy));

  // value labels
  innerChart
    .selectAll(".bar-label")
    .data(data)
    .join("text")
      .attr("class", "bar-label")
      .text(d => Math.round(d.energy))
      .attr("x", d => xScale(d.screenTech) + xScale.bandwidth() / 2)
      .attr("y", d => yScale(d.energy) - 8)
      .attr("text-anchor", "middle")
      .style("font-size", "13px");
};