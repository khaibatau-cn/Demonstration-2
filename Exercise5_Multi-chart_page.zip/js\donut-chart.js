// Exercise 5.3: Donut chart

// Ex 5.3: Load data
d3.csv("data/tv_size_count.csv", d => {
  return {
    size: d.size,
    count: +d.count
  };
}).then(data => {
  console.log(data);
  drawDonutChart(data);
});

const drawDonutChart = data => {

  // Ex 5.3: Size and radius
  const width = 800;
  const height = 400;
  const padding = 20;
  const radius = Math.min(width, height) / 2 - padding;

  // Ex 5.3: Colour scale
  const colorScale = d3.scaleOrdinal()
    .domain(data.map(d => d.size))
    .range(["#2a78d6", "#eb6834", "#1baf7a"]);

  // Ex 5.3: Pie angles
  const pieGenerator = d3.pie()
    .value(d => d.count)
    .sort(null);

  const annotatedData = pieGenerator(data);
  console.log(annotatedData);

  // Ex 5.3: Arc generator
  const arcGenerator = d3.arc()
    .innerRadius(radius * 0.6)
    .outerRadius(radius)
    .padAngle(0.02)
    .cornerRadius(4);

  // Ex 5.3: SVG container
  const svg = d3.select("#donut-chart")
    .append("svg")
      .attr("viewBox", `0 0 ${width} ${height}`);

  const innerChart = svg
    .append("g")
      .attr("transform", `translate(${width / 2}, ${height / 2})`);

  // Ex 5.3: Draw arcs
  innerChart
    .selectAll(".arc")
    .data(annotatedData)
    .join("path")
      .attr("class", "arc")
      .attr("d", arcGenerator)
      .attr("fill", d => colorScale(d.data.size))
    .append("title")
      .text(d => `${d.data.size}: ${d.data.count} models`);

  // Ex 5.3: Labels
  const total = d3.sum(data, d => d.count);

  const labels = innerChart
    .selectAll(".slice-label")
    .data(annotatedData)
    .join("text")
      .attr("class", "slice-label")
      .attr("transform", d => `translate(${arcGenerator.centroid(d)})`)
      .attr("text-anchor", "middle")
      .style("font-size", "14px");

  labels.append("tspan")
    .text(d => d.data.size)
    .attr("x", 0)
    .attr("dy", "-0.2em")
    .style("font-weight", "bold");

  labels.append("tspan")
    .text(d => d3.format(".0%")(d.data.count / total))
    .attr("x", 0)
    .attr("dy", "1.2em");

  // Ex 5.3: Total in the centre
  innerChart
    .append("text")
      .text(`${d3.format(",")(total)} models`)
      .attr("text-anchor", "middle")
      .attr("dominant-baseline", "middle")
      .style("font-size", "16px");
};
