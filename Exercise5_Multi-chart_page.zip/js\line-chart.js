// Exercise 5.2: Scatter plot and line chart

// Ex 5.2: Load data
d3.csv("data/ARE_Spot_Prices.csv", d => {
  return {
    year: +d.Year,
    averagePrice: +d["Average Price (notTas-Snowy)"]
  };
}).then(data => {
  console.log(data);
  data.sort((a, b) => a.year - b.year);
  drawLineChart(data);
});

const drawLineChart = data => {

  // Ex 5.2: Margins and size
  const margin = { top: 40, right: 30, bottom: 50, left: 70 };
  const width = 800;
  const height = 400;
  const innerWidth = width - margin.left - margin.right;
  const innerHeight = height - margin.top - margin.bottom;

  // Ex 5.2: Scales
  const xScale = d3.scaleLinear()
    .domain(d3.extent(data, d => d.year))
    .range([0, innerWidth]);

  const yScale = d3.scaleLinear()
    .domain([0, d3.max(data, d => d.averagePrice)])
    .range([innerHeight, 0])
    .nice();

  // Ex 5.2: Axes
  const bottomAxis = d3.axisBottom(xScale)
    .tickFormat(d3.format("d"));
  const leftAxis = d3.axisLeft(yScale);

  // Ex 5.2: SVG container and inner chart
  const svg = d3.select("#line-chart")
    .append("svg")
      .attr("viewBox", `0 0 ${width} ${height}`);

  const innerChart = svg
    .append("g")
      .attr("transform", `translate(${margin.left}, ${margin.top})`);

  innerChart
    .append("g")
      .attr("class", "axis-x")
      .attr("transform", `translate(0, ${innerHeight})`)
      .call(bottomAxis);

  innerChart
    .append("g")
      .attr("class", "axis-y")
      .call(leftAxis);

  // Ex 5.2: Axis labels
  svg
    .append("text")
      .attr("class", "axis-label")
      .text("Average spot price ($/MWh)")
      .attr("x", 0)
      .attr("y", 20);

  svg
    .append("text")
      .attr("class", "axis-label")
      .text("Year")
      .attr("x", margin.left + innerWidth / 2)
      .attr("y", height - 8)
      .attr("text-anchor", "middle");

  // Ex 5.2: Scatter plot
  innerChart
    .selectAll("circle")
    .data(data)
    .join("circle")
      .attr("class", "dot")
      .attr("r", 4)
      .attr("cx", d => xScale(d.year))
      .attr("cy", d => yScale(d.averagePrice))
      .attr("fill", "#2a78d6")
    .append("title")
      .text(d => `${d.year}: $${d.averagePrice}/MWh`);

  // Ex 5.2: Line generator
  const lineGenerator = d3.line()
    .x(d => xScale(d.year))
    .y(d => yScale(d.averagePrice));

  // Ex 5.2: Draw the line
  innerChart
    .append("path")
      .attr("class", "line")
      .attr("d", lineGenerator(data));

  innerChart.selectAll("circle").raise();

  // Ex 5.2: Line label
  const last = data[data.length - 1];
  innerChart
    .append("text")
      .text(`$${last.averagePrice}`)
      .attr("x", xScale(last.year))
      .attr("y", yScale(last.averagePrice) - 12)
      .attr("text-anchor", "end")
      .style("font-size", "13px");
};
