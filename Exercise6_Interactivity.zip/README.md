# Exercise 6 - Interactivity

COS30045 Data Visualisation

A histogram with filters and a scatterplot with tooltips, built with D3.js.

## Files

- `index.html` - page
- `js/load-data.js` - loads the data
- `js/shared-constants.js` - shared values
- `js/histogram.js` - Ex 6.1 histogram
- `js/interactions.js` - Ex 6.2 filters and Ex 6.4 tooltips
- `js/scatterplot.js` - Ex 6.3 scatterplot
- `css/` - styles
- `data/` - TV data
- `W6 TV Data.knwf` - KNIME workflow

GenAI was used in this exercise. See the GenAI declaration on Canvas.
