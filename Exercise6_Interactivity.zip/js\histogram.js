// Exercise 6.1: Histogram
const drawHistogram = data => {

  // Ex 6.1: SVG container and inner chart
  const svg = d3.select("#histogram")
    .append("svg")
      .attr("viewBox", `0 0 ${width} ${height}`);

  const innerChart = svg
    .append("g")
      .attr("transform", `translate(${margin.left}, ${margin.top})`);

  // Ex 6.1: Bins
  const bins = binGenerator(data);
  console.log(bins);

  // Ex 6.1: Scales
  const minEng = bins[0].x0;
  const maxEng = bins[bins.length - 1].x1;
  const binsMaxLength = d3.max(bins, d => d.length);

  xScale
    .domain([minEng, maxEng])
    .range([0, innerWidth]);

  yScale
    .domain([0, binsMaxLength])
    .range([innerHeight, 0])
    .nice();

  // Ex 6.1: Bars
  innerChart
    .selectAll("rect")
    .data(bins)
    .join("rect")
      .attr("x", d => xScale(d.x0))
      .attr("y", d => yScale(d.length))
      .attr("width", d => xScale(d.x1) - xScale(d.x0))
      .attr("height", d => innerHeight - yScale(d.length))
      .attr("fill", barColor)
      .attr("stroke", bodyBackgroundColor)
      .attr("stroke-width", 2);

  // Ex 6.1: Axes
  const bottomAxis = d3.axisBottom(xScale)
    .tickValues(d3.range(0, 3000, 400));
  const leftAxis = d3.axisLeft(yScale)
    .ticks(8);

  innerChart
    .append("g")
      .attr("class", "axis-x")
      .attr("transform", `translate(0, ${innerHeight})`)
      .call(bottomAxis);

  innerChart
    .append("g")
      .attr("class", "axis-y")
      .call(leftAxis);

  // Ex 6.1: Axis labels
  svg
    .append("text")
      .attr("class", "axis-label")
      .text("Labelled energy consumption (kWh/year)")
      .attr("x", margin.left + innerWidth / 2)
      .attr("y", height - 12)
      .attr("text-anchor", "middle");

  svg
    .append("text")
      .attr("class", "axis-label")
      .text("Number of TV models")
      .attr("x", 0)
      .attr("y", 20);
};
