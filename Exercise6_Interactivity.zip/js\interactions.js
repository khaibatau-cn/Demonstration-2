// Exercise 6.2: Filters
const populateFilters = data => {

  // Ex 6.2: Filter buttons
  d3.select("#filters_screen")
    .selectAll(".filter")
    .data(filters_screen)
    .join("button")
      .attr("class", d => `filter ${d.isActive ? "active" : ""}`)
      .text(d => d.label)

      // Ex 6.2: Click event
      .on("click", (e, d) => {
        console.log(e, d);

        // Ex 6.2: Update active filter
        if (!d.isActive) {
          filters_screen.forEach(filter => {
            filter.isActive = d.id === filter.id;
          });

          d3.selectAll("#filters_screen .filter")
            .classed("active", filter => filter.id === d.id);

          updateHistogram(d.id, data);
        }
      });

  // Ex 6.2: Update histogram
  const updateHistogram = (filterId, data) => {

    const updatedData = filterId === "all"
      ? data
      : data.filter(tv => tv.screenTech === filterId);

    const updatedBins = binGenerator(updatedData);

    // Ex 6.2 Extension: Rescale y-axis
    yScale.domain([0, d3.max(updatedBins, d => d.length) || 1]).nice();

    d3.select("#histogram .axis-y")
      .transition()
        .duration(500)
        .call(d3.axisLeft(yScale).ticks(8));

    // Ex 6.2: Animate bars
    d3.select("#histogram")
      .selectAll("rect")
      .data(updatedBins)
      .transition()
        .duration(500)
        .ease(d3.easeCubicInOut)
        .attr("y", d => yScale(d.length))
        .attr("height", d => innerHeight - yScale(d.length));
  };
};

// Exercise 6.4: Tooltip
const createTooltip = () => {

  // Ex 6.4: Tooltip group
  const tooltip = innerChartS
    .append("g")
      .attr("class", "tooltip")
      .style("opacity", 0)
      .style("pointer-events", "none");

  // Ex 6.4: Tooltip background
  tooltip
    .append("rect")
      .attr("width", tooltipWidth)
      .attr("height", tooltipHeight)
      .attr("rx", 6)
      .attr("ry", 6)
      .attr("fill", barColor)
      .attr("fill-opacity", 0.9);

  // Ex 6.4: Tooltip text
  const text = tooltip
    .append("text")
      .attr("x", tooltipWidth / 2)
      .attr("y", 21)
      .attr("text-anchor", "middle");

  text.append("tspan").attr("class", "tooltip-title").attr("x", tooltipWidth / 2).style("font-weight", 600);
  text.append("tspan").attr("class", "tooltip-detail").attr("x", tooltipWidth / 2).attr("dy", 19);
};

// Ex 6.4: Mouse events
const handleMouseEvents = () => {

  innerChartS.selectAll("circle")

    // Ex 6.4: Show tooltip
    .on("mouseenter", (e, d) => {
      console.log(e, d);

      d3.select(".tooltip-title")
        .text(`${d.brand.toUpperCase()} ${d.model}`);
      d3.select(".tooltip-detail")
        .text(`${d.screenSize}" ${d.screenTech}, ${d.star} stars, ${d.energyConsumption} kWh`);

      const cx = +e.target.getAttribute("cx");
      const cy = +e.target.getAttribute("cy");

      const x = Math.max(0, Math.min(cx - tooltipWidth / 2, innerWidth - tooltipWidth));
      const y = cy - tooltipHeight - 12 < 0
        ? cy + 12
        : cy - tooltipHeight - 12;

      d3.select(".tooltip")
        .attr("transform", `translate(${x}, ${y})`)
        .transition()
          .duration(200)
          .style("opacity", 1);

      d3.select(e.target)
        .attr("r", 7)
        .attr("opacity", 1);
    })

    // Ex 6.4: Hide tooltip
    .on("mouseleave", (e, d) => {
      d3.select(".tooltip")
        .interrupt()
        .style("opacity", 0)
        .attr("transform", "translate(0, 500)");

      d3.select(e.target)
        .attr("r", 4)
        .attr("opacity", 0.5);
    });
};
