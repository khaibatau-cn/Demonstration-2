// Exercise 6.1: Load data
d3.csv("data/Ex6_TVdata_withStar.csv", d => {
  return {
    brand: d.brand,
    model: d.model,
    screenSize: +d.screenSize,
    screenTech: d.screenTech,
    star: +d.star,
    energyConsumption: +d.energyConsumption
  };
}).then(data => {
  console.log(data);

  // Ex 6.1: Histogram
  drawHistogram(data);

  // Ex 6.2: Filters
  populateFilters(data);

  // Ex 6.3: Scatterplot
  drawScatterplot(data);

  // Ex 6.4: Tooltip
  createTooltip();
  handleMouseEvents();
});
