// Exercise 6.3: Scatterplot
const drawScatterplot = data => {

  // Ex 6.3: SVG container and inner chart
  const svg = d3.select("#scatterplot")
    .append("svg")
      .attr("viewBox", `0 0 ${width} ${height}`);

  innerChartS = svg
    .append("g")
      .attr("transform", `translate(${margin.left}, ${margin.top})`);

  // Ex 6.3: Scales
  const maxStar = d3.max(data, d => d.star);
  const maxEnergy = d3.max(data, d => d.energyConsumption);

  xScaleS
    .domain([0, maxStar])
    .range([0, innerWidth]);

  yScaleS
    .domain([0, maxEnergy])
    .range([innerHeight, 0])
    .nice();

  // Ex 6.3: Colour scale
  colorScale
    .domain(["LED", "LCD", "OLED"])
    .range(["#2a78d6", "#eb6834", "#1baf7a"]);

  // Ex 6.3: Circles
  innerChartS
    .selectAll("circle")
    .data(data)
    .join("circle")
      .attr("r", 4)
      .attr("cx", d => xScaleS(d.star))
      .attr("cy", d => yScaleS(d.energyConsumption))
      .attr("fill", d => colorScale(d.screenTech))
      .attr("opacity", 0.5);

  // Ex 6.3: Axes
  const bottomAxis = d3.axisBottom(xScaleS);
  const leftAxis = d3.axisLeft(yScaleS)
    .ticks(8);

  innerChartS
    .append("g")
      .attr("class", "axis-x")
      .attr("transform", `translate(0, ${innerHeight})`)
      .call(bottomAxis);

  innerChartS
    .append("g")
      .attr("class", "axis-y")
      .call(leftAxis);

  // Ex 6.3: Axis labels
  svg
    .append("text")
      .attr("class", "axis-label")
      .text("Star rating")
      .attr("x", margin.left + innerWidth / 2)
      .attr("y", height - 12)
      .attr("text-anchor", "middle");

  svg
    .append("text")
      .attr("class", "axis-label")
      .text("Labelled energy consumption (kWh/year)")
      .attr("transform", "rotate(-90)")
      .attr("x", -(margin.top + innerHeight / 2))
      .attr("y", 20)
      .attr("text-anchor", "middle");

  // Ex 6.3: Legend
  const legend = svg
    .append("g")
      .attr("class", "legend")
      .attr("transform", `translate(${width - margin.right - 90}, ${margin.top})`);

  colorScale.domain().forEach((tech, i) => {
    const item = legend
      .append("g")
        .attr("transform", `translate(0, ${i * 20})`);

    item.append("rect")
      .attr("width", 12)
      .attr("height", 12)
      .attr("rx", 2)
      .attr("fill", colorScale(tech));

    item.append("text")
      .text(tech)
      .attr("x", 20)
      .attr("y", 10);
  });
};
