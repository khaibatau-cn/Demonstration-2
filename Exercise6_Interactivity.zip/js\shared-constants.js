// Ex 6.1: Chart size and margins
const margin = { top: 40, right: 30, bottom: 60, left: 80 };
const width = 800;
const height = 420;
const innerWidth = width - margin.left - margin.right;
const innerHeight = height - margin.top - margin.bottom;

// Ex 6.1: Colours
const barColor = "#2a78d6";
const bodyBackgroundColor = "#ffffff";
const fontColor = "#5b6170";

// Ex 6.1: Histogram scales
const xScale = d3.scaleLinear();
const yScale = d3.scaleLinear();

// Ex 6.1: Bin generator
const binGenerator = d3.bin()
  .value(d => d.energyConsumption)
  .domain([0, 2800])
  .thresholds(d3.range(0, 2800, 200));

// Ex 6.2: Filters
const filters_screen = [
  { id: "all", label: "All", isActive: true },
  { id: "LED", label: "LED", isActive: false },
  { id: "LCD", label: "LCD", isActive: false },
  { id: "OLED", label: "OLED", isActive: false }
];

// Ex 6.3: Scatterplot inner chart and scales
let innerChartS;
const xScaleS = d3.scaleLinear();
const yScaleS = d3.scaleLinear();
const colorScale = d3.scaleOrdinal();

// Ex 6.4: Tooltip size
const tooltipWidth = 230;
const tooltipHeight = 52;
